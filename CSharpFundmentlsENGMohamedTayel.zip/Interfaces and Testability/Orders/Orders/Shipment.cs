﻿using System;

namespace Orders
{
    public class Shipment
    {
        public Shipment()
        {
        }

        public float Cost { get;  set; }
        public DateTime ShippingDate { get;  set; }
    }
}