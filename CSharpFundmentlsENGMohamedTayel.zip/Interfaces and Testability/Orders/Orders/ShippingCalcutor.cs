﻿using System;

namespace Orders
{
    public class ShippingCalcutor: IShippingCalcutor
    {

        public float  CalculateShipping(Order order)
        {
            if (order.TotalPrice < 30f)
                return order.TotalPrice * 0.1f;
            return 0;
        }
    }
}