﻿namespace LambdaExpressions
{
    public class MuneItem
    {
        public string Title { get; internal set; }
        public float Price { get; internal set; }
    }
}