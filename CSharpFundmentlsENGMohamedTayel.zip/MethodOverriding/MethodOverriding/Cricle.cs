﻿using System;
namespace MethodOverriding
{
    public class Cricle : Shap
    {
        public override void Draw()
        {
            Console.WriteLine("Draw Cricle");

        }
    }
}
