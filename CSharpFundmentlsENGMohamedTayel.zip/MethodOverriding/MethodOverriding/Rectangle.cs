﻿namespace MethodOverriding
{
    public class Rectangle:Shap
    {
        public override void Draw()
        {
            System.Console.WriteLine("");
        }
    }
}
