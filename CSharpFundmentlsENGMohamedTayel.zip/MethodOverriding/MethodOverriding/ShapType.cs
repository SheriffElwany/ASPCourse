﻿namespace MethodOverriding
{
    public enum ShapType
    {
        Cricle,
        Rectangle
    }
}