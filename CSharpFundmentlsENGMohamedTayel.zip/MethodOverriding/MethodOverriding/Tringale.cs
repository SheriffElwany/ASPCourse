﻿namespace MethodOverriding
{
    public class Tringale:Shap
    {

    }
}
