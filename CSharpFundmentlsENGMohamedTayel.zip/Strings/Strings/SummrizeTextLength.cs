﻿namespace Strings
{
    public enum SummrizeTextLength
    {
        MaxLenght=30
    }
}
