﻿namespace UpcastingAndDowncasting
{
    public class Shap
    {
        public int Width { get; set; }
        public int Hight { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
    }
}
